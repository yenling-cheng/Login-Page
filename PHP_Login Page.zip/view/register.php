

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sign Up PHP</title>
    <link rel="stylesheet" href="styles_register.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
	  <div class="d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <form action="register_check.php" method="post">
	  		<h1 class="text-center pb-5 display-4">Sign Up</h1>
            <?php if (isset($_GET['error'])) { ?>
     		    <p class="error"><?php echo $_GET['error']; ?></p>
     	    <?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

		  <div class="mb-3">
		    <label for="exampleInputName" 
		           class="form-label">Name
		    </label>
		    <?php if (isset($_GET['name'])) { ?>
               <input type="text" 
                      name="name" 
                      placeholder="Name"
                      value="<?php echo $_GET['name']; ?>"><br>
            <?php }else{ ?>
                <input type="text" 
                      name="name" 
                      placeholder="Name"><br>
          <?php }?>
		  </div>

		  <div class="mb-3">
		    <label for="exampleInputPassword1" 
		           class="form-label">E-mail
		    </label>
            <?php if (isset($_GET['email'])) { ?>
                <input type="text" 
                      name="email" 
                      placeholder="E-mail"
                      value="<?php echo $_GET['email']; ?>"><br>
            <?php }else{ ?>
                <input type="text" 
                      name="email" 
                      placeholder="E-mail"><br>
          <?php }?>
		  </div>

          <div class="mb-3">
		    <label for="exampleInputPassword1" 
		           class="form-label">Password
		    </label>
            <input type="password" 
                 name="password" 
                 placeholder="Password"><br>
		  </div>


        <div class="mb-3">
		    <label for="exampleInputPassword1" 
		           class="form-label">Re Password
		    </label>
            <input type="password" 
                 name="re_password" 
                 placeholder="Re_Password"><br>
		</div>

        <button type="submit">Sign Up</button>
          <a href="index.php" class="ca">Already have an account?</a>
		</form>
	  </div>
</body>

</html>