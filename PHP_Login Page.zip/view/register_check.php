<?php 
session_start(); 
include "db_conn.php";


if (isset($_POST['email']) && isset($_POST['password'])
    && isset($_POST['name']) && isset($_POST['re_password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$email = validate($_POST['email']);
	$pass = validate($_POST['password']);
	$re_pass = validate($_POST['re_password']);
	$name = validate($_POST['name']);

	$user_data = 'email='. $email. '&name='. $name;
//	echo $user_data;


	if (empty($name)) {
		header("Location: register.php?error=Name is required&$user_data");
	    exit();
	}else if(empty($pass)){
        header("Location: register.php?error=Password is required&$user_data");
	    exit();
	}
	else if(empty($re_pass)){
        header("Location: register.php?error=Re Password is required&$user_data");
	    exit();
	}

	else if(empty($email)){
        header("Location: register.php?error=Your e-mail is required&$user_data");
	    exit();
	}

	else if($pass !== $re_pass){
        header("Location: register.php?error=The confirmation password  does not match&$user_data");
	    exit();
	}else{

		// hash the password
        $pass = md5($pass);

	    $sql = "SELECT * FROM users WHERE full_name='$name' ";
	//	$result = mysqli_query($conn, $sql);
	//	echo "so far";
           $sql2 = "INSERT INTO users(full_name, email, password) VALUES('$name', '$email', '$pass')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location: register.php?success=Your account has been created successfully");
	         exit();
           }else {
			   echo "cool";
	           	//header("Location: register.php?error=unknown error occurred&$user_data");
		        exit();
           }
	
	}
	
}else{
	header("Location: register.php");
	exit();
}
