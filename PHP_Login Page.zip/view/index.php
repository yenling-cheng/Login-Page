<?php 
  session_start();

  if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) { 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>resume</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <link rel="stylesheet" href="styles.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
</head>
<body>


<form action="index.php" method="POST" align="center" > 
  <div class="d-flex justify-content-center align-items-center flex-column" style="min-height: 25vh;">
        <h1 class="text-center display-4" style="margin-top: 30px;font-size: 2rem">Welcome! <?=$_SESSION['user_full_name']?></h1>
        <a href="logout.php" class="btn btn-warning">LOGOUT</a>
        <br>
        <a href="change_password.php" class="btn btn-warning">Change Password</a>
	 </div>
   
</form>
<div class="resume">
   <div class="resume_left">
     <div class="resume_profile">
       <img src="profile.jpg" alt="profile_pic">
     </div>
     <div class="resume_content">
       <div class="resume_item resume_info">
         <div class="title">
           <p class="bold">Guinea Pig</p>
           <p class="regular">a really happy piggy</p>
         </div>
         <ul>
           <li>
             <div class="data">
               Hsinhcu, Taiwan
             </div>
           </li>
           <li>
             <div class="data">
               +886 5151515151
             </div>
           </li>
           <li>
             <div class="data">
               happy.pig2001@gmail.com
             </div>
           </li>
         </ul>
       </div>
       <div class="resume_item resume_skills">
         <div class="title">
           <p class="bold">Skills</p>
         </div>
         <ul>
           <li>
             <div class="skill_name">
               <b>TOEFL</b>
             </div>
             <div class="skill_progress">
               <span style="width: 86%;"></span>
             </div>
             <div class="skill_per">103/120</div>
           </li>
           <li>
             <div class="skill_name">
               <b>TOEIC</b>
             </div>
             <div class="skill_progress">
               <span style="width: 92%;"></span>
             </div>
             <div class="skill_per">915/990</div>
           </li>
           <li>
             <div class="skill_name">
               <b>C++</b>
             </div>
             <div class="skill_progress">
               <span style="width: 30%;"></span>
             </div>
             <div class="skill_per">30%</div>
           </li>
           <li>
             <div class="skill_name">
               <b>HTML</b>
             </div>
             <div class="skill_progress">
               <span style="width: 3%;"></span>
             </div>
             <div class="skill_per">3%</div>
           </li>
         </ul>
       </div>
       <div class="resume_item resume_social">
         <div class="title">
           <p class="bold">Social</p>
         </div>
         <ul>
           <li>
             <div class="icon">
               <i class="fab fa-facebook-square"></i>
             </div>
             <div class="data">
               <p class="semi-bold">Facebook</p>
               <p>GuineaPig@facebook</p>
             </div>
           </li>
           <li>
             <div class="icon">
               <i class="fab fa-youtube"></i>
             </div>
             <div class="data">
               <p class="semi-bold">Youtube</p>
               <p>HappyPiggyLife@youtube</p>
             </div>
           </li>
           <li>
             <div class="icon">
               <i class="fab fa-instagram"></i>
             </div>
             <div class="data">
               <p class="semi-bold">IG</p>
               <p>Happy Guinea Pig</p>
             </div>
           </li>
         </ul>
       </div>
     </div>
  </div>
  <div class="resume_right">
    <div class="resume_item resume_about">
        <div class="title">
           <p class="bold">About Me</p>
         </div>
        <p>I am a really happy guinea pig, probably the happiest guinea pig in the world :) All I have to do is to eat and to please all the human beings on the planet!</p>
    </div>
    <div class="resume_item resume_work">
        <div class="title">
           <p class="bold">My Experiences</p>
         </div>
        <ul>
            <li>
                <div class="date">2015 - 2021</div> 
                <div class="info">
                     <p class="semi-bold">Being the Happiest Piggy in da World</p> 
                  <p>I eat, I drink, I sleep, and I do nothing :D</p>
                </div>
            </li>
            <li>
              <div class="date">2013 - 2015</div>
              <div class="info">
                     <p class="semi-bold">Be Happier Than Before</p> 
                  <p>I eat, I drink, I sleep, and I do nothing :D</p>
                </div>
            </li>
            <li>
              <div class="date">2010 - 2013</div>
              <div class="info">
                     <p class="semi-bold">Born to Be Happy</p> 
                  <p>I eat, I drink, I sleep, and I do nothing :D</p>
                </div>
            </li>
        </ul>
    </div>
    <div class="resume_item resume_education">
      <div class="title">
           <p class="bold">Education</p>
         </div>
      <ul>
            <li>
                <div class="date">2010 - 2020</div> 
                <div class="info">
                     <p class="semi-bold">Happy Guinea Pig University</p> 
                  <p>Double majoring in Eating and Sleeping.</p>
                </div>
            </li>
            <li>
              <div class="date">2001 - 2010</div>
              <div class="info">
                     <p class="semi-bold">Happy Piggy Kindergarton</p> 
                  <p>My mom said I was born to be happy!</p>
                </div>
            </li>
        </ul>
    </div>
    <div class="resume_item resume_hobby">
      <div class="title">
           <p class="bold">Hobbies</p>
         </div>
       <ul>
         <li><i class="fas fa-utensils"></i></li>
         <li><i class="fas fa-bed"></i></li>
         <li><i class="fas fa-toilet"></i></li>
         <li><i class="fas fa-laugh-beam"></i></li>
      </ul>
    </div>
  </div>
  </div>
</body>
</html>
<?php 
}else {
   header("Location: login.php");
}
 ?>
